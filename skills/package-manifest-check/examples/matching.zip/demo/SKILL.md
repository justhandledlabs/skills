Synthetic example instructions.
